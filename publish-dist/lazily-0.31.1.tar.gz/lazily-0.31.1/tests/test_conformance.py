"""Cross-language conformance tests for the lazily IPC wire protocol.

Each test loads a canonical JSON fixture and validates that lazily-py agrees on
the wire format. The fixtures are the same files the Rust and Zig bindings test
against, so all implementations stay byte-compatible.

The canonical fixtures live in the sibling ``lazily-spec/conformance`` repo; a
vendored copy under ``tests/conformance`` keeps this binding's standalone CI
self-contained. The spec copy is preferred when present.

Fixture schema::

    {
      "description": "…",
      "protocol_version": 1,
      "kind": "Snapshot" | "Delta",
      "assertions": { … language-agnostic field checks … },
      "wire": { <IpcMessage as serde_json> }
    }
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from lazily.ipc import (
    BlobBackendKind,
    CausalReceipt,
    CausalReceipts,
    DeltaOp_SlotValue,
    IpcMessage,
    IpcValue_SharedBlob,
    NodeState_Opaque,
    NodeState_Payload,
    NodeState_SharedBlob,
    ReceiptApplyResult,
    ReceiptOutcome,
    ReceiptProjection,
    ShmBlobArena,
)


_LOCAL_FIXTURES = Path(__file__).resolve().parent / "conformance"
_SPEC_FIXTURES = Path(__file__).resolve().parents[2] / "lazily-spec" / "conformance"


def load_fixture(name: str) -> dict:
    spec_path = _SPEC_FIXTURES / name
    path = spec_path if spec_path.exists() else _LOCAL_FIXTURES / name
    fixture = json.loads(path.read_text())
    assert fixture["protocol_version"] == 1, (
        f"fixture {name} uses unsupported protocol version"
    )
    return fixture


def parse_wire(fixture: dict) -> IpcMessage:
    return IpcMessage.from_wire(fixture["wire"])


def assert_round_trip_json(message: IpcMessage, fixture: dict) -> None:
    # Round-trip parity: re-serializing the parsed message yields the same
    # canonical JSON object as the fixture wire.
    assert message.to_wire() == fixture["wire"], (
        f"round-trip JSON mismatch for fixture: {fixture['description']}"
    )
    # And bytes decode back to an equal message.
    assert IpcMessage.decode_json(message.encode_json()) == message


# ---------------------------------------------------------------------------
# Snapshot fixtures
# ---------------------------------------------------------------------------


def test_conformance_snapshot_minimal() -> None:
    fixture = load_fixture("snapshot_minimal.json")
    assert fixture["kind"] == "Snapshot"
    a = fixture["assertions"]

    message = parse_wire(fixture)
    assert message.is_snapshot
    snap = message.snapshot

    assert snap.epoch == a["epoch"]
    assert len(snap.nodes) == a["node_count"]
    assert len(snap.edges) == a["edge_count"]
    assert len(snap.roots) == a["root_count"]
    assert snap.nodes[0].type_tag == a["first_node_type_tag"]
    assert isinstance(snap.nodes[0].state, NodeState_Payload)

    assert_round_trip_json(message, fixture)


def test_conformance_snapshot_multi_node() -> None:
    fixture = load_fixture("snapshot_multi_node.json")
    assert fixture["kind"] == "Snapshot"
    a = fixture["assertions"]

    message = parse_wire(fixture)
    snap = message.snapshot
    assert snap.epoch == 7
    assert len(snap.nodes) == 3
    assert len(snap.edges) == 2
    assert len(snap.roots) == 2

    opaque_id = a["opaque_node_id"]
    opaque_node = next(n for n in snap.nodes if n.node == opaque_id)
    assert isinstance(opaque_node.state, NodeState_Opaque)

    assert_round_trip_json(message, fixture)


def test_conformance_snapshot_shared_blob() -> None:
    fixture = load_fixture("snapshot_shared_blob.json")
    assert fixture["kind"] == "Snapshot"

    message = parse_wire(fixture)
    snap = message.snapshot
    assert snap.epoch == 9
    assert len(snap.nodes) == 1

    state = snap.nodes[0].state
    assert isinstance(state, NodeState_SharedBlob)
    assert state.blob.offset == 0
    assert state.blob.len == 16
    assert state.blob.epoch == 9

    assert_round_trip_json(message, fixture)


# ---------------------------------------------------------------------------
# Delta fixtures
# ---------------------------------------------------------------------------


def test_conformance_delta_sequential() -> None:
    fixture = load_fixture("delta_sequential.json")
    assert fixture["kind"] == "Delta"
    a = fixture["assertions"]

    message = parse_wire(fixture)
    assert message.is_delta
    delta = message.delta

    assert delta.base_epoch == a["base_epoch"]
    assert delta.epoch == a["epoch"]
    assert delta.is_next_after(a["base_epoch"])
    assert not delta.is_next_after(a["base_epoch"] - 1)

    assert len(delta.ops) == a["op_count"]

    seen = {type(op).__name__ for op in delta.ops}
    assert seen == {
        "DeltaOp_CellSet",
        "DeltaOp_SlotValue",
        "DeltaOp_Invalidate",
        "DeltaOp_NodeAdd",
        "DeltaOp_NodeRemove",
        "DeltaOp_EdgeAdd",
        "DeltaOp_EdgeRemove",
    }
    assert len(seen) == 7

    assert_round_trip_json(message, fixture)


def test_conformance_delta_non_sequential() -> None:
    fixture = load_fixture("delta_non_sequential.json")
    assert fixture["kind"] == "Delta"

    message = parse_wire(fixture)
    delta = message.delta
    assert delta.base_epoch == 12
    assert delta.epoch == 13
    assert delta.is_next_after(12)
    assert not delta.is_next_after(10)

    status = delta.apply_status(10)
    assert status.is_resync_required
    assert status.last_epoch == 10
    assert status.base_epoch == 12
    assert status.epoch == 13

    assert_round_trip_json(message, fixture)


def test_conformance_delta_shared_blob() -> None:
    fixture = load_fixture("delta_shared_blob.json")
    assert fixture["kind"] == "Delta"

    message = parse_wire(fixture)
    delta = message.delta
    assert delta.base_epoch == 8
    assert delta.epoch == 9
    assert len(delta.ops) == 1

    op = delta.ops[0]
    assert isinstance(op, DeltaOp_SlotValue)
    assert isinstance(op.payload, IpcValue_SharedBlob)
    assert op.payload.blob.offset == 40
    assert op.payload.blob.len == 17
    assert op.payload.blob.epoch == 9
    # A `backend`-absent descriptor defaults to shm (backward compatibility).
    assert op.payload.blob.backend is BlobBackendKind.SHM

    assert_round_trip_json(message, fixture)


def test_conformance_delta_zero_copy_arrow() -> None:
    # Zero-copy transport (#lzzcpy): the SharedBlob descriptor carries the
    # optional `backend` discriminator selecting a pluggable backend.
    fixture = load_fixture("delta_zero_copy_arrow.json")
    assert fixture["kind"] == "Delta"
    a = fixture["assertions"]

    message = parse_wire(fixture)
    delta = message.delta
    assert delta.base_epoch == a["base_epoch"]
    assert delta.epoch == a["epoch"]
    assert len(delta.ops) == a["op_count"]

    op = delta.ops[0]
    assert isinstance(op, DeltaOp_SlotValue)
    assert isinstance(op.payload, IpcValue_SharedBlob)
    assert op.payload.blob.backend is BlobBackendKind.ARROW
    assert op.payload.blob.backend.value == a["first_op_payload_backend"]

    # The `backend` discriminator survives a JSON round-trip byte-for-byte.
    assert_round_trip_json(message, fixture)


# ---------------------------------------------------------------------------
# ShmBlobArena host fixture (not a wire type — locks the arena byte contract)
# ---------------------------------------------------------------------------


def test_conformance_arena_blob() -> None:
    fixture = load_fixture("arena_blob.json")
    assert fixture["kind"] == "Arena"
    a = fixture["assertions"]

    arena = ShmBlobArena.with_capacity(fixture["input"]["capacity"])
    payload = bytes(fixture["input"]["payload"])
    desc = arena.write_blob(fixture["input"]["epoch"], payload)

    expected_desc = fixture["expected"]["descriptor"]
    assert desc.offset == expected_desc["offset"]
    assert desc.len == expected_desc["len"]
    assert desc.generation == expected_desc["generation"]
    assert desc.epoch == expected_desc["epoch"]
    assert desc.checksum == expected_desc["checksum"]

    # 40-byte LZSH header byte-identical across rs / py / zig
    buf = arena.buffer()
    header_len = a["header_len"]
    assert bytes(buf[0:header_len]) == bytes(fixture["expected"]["header_bytes"])
    assert bytes(buf[header_len : header_len + len(payload)]) == bytes(
        fixture["expected"]["payload_region"]
    )

    # round-trip
    assert bytes(arena.read_blob(desc)) == payload


# ---------------------------------------------------------------------------
# Every fixture round-trips, parametrized
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "name",
    [
        "snapshot_minimal.json",
        "snapshot_multi_node.json",
        "snapshot_shared_blob.json",
        "delta_sequential.json",
        "delta_non_sequential.json",
        "delta_shared_blob.json",
        "delta_zero_copy_arrow.json",
    ],
)
def test_fixture_round_trips(name: str) -> None:
    fixture = load_fixture(name)
    message = parse_wire(fixture)
    assert message.to_wire() == fixture["wire"]
    assert IpcMessage.decode_json(message.encode_json()) == message


# ---------------------------------------------------------------------------
# Causal receipt fixture (outcome projection — NOT a transport ACK)
# ---------------------------------------------------------------------------


def test_conformance_causal_receipts() -> None:
    fixture = load_fixture("receipts/causal_receipts.json")
    assert fixture["kind"] == "Receipt"
    assert fixture["model"] == "CausalReceipt"
    a = fixture["assertions"]

    frame = CausalReceipts.from_wire(fixture["wire"])
    assert len(frame.receipts) == a["receipt_count"]

    # Round-trip parity: re-serializing the parsed frame yields the same wire.
    assert frame.to_wire() == fixture["wire"]
    assert CausalReceipts.decode_json(frame.encode_json()) == frame

    # The frame is not an IpcMessage variant; it is its own externally-tagged
    # envelope, and survives a bytes round-trip.
    assert set(frame.to_wire().keys()) == {"CausalReceipts"}

    causation = a["causation_id"]
    groups = frame.group_by_causation()
    assert set(groups.keys()) == {causation}

    # Default authority = max generation seen among the matching receipts,
    # which makes the older generation stale (the fixture's invariant).
    projection = ReceiptProjection.from_receipts(causation, frame.receipts)
    assert projection.current_generation == a["current_generation"]
    assert projection.terminal_outcome is ReceiptOutcome.APPLIED
    assert projection.is_terminal
    assert not projection.in_conflict
    assert projection.stale_receipt_ids() == a["stale_receipt_ids"]
    assert projection.nonterminal_outcomes() == [
        ReceiptOutcome.OBSERVED,
        ReceiptOutcome.ACCEPTED,
    ]

    # The fixture orders receipts observed -> accepted -> applied -> stale.
    observed, accepted, applied, stale = frame.receipts
    assert observed.outcome is ReceiptOutcome.OBSERVED
    assert accepted.outcome is ReceiptOutcome.ACCEPTED
    assert applied.outcome is ReceiptOutcome.APPLIED
    assert applied.payload_hash is not None
    assert applied.payload_hash.startswith("sha256:")
    assert stale.outcome is ReceiptOutcome.REJECTED
    assert stale.generation < projection.current_generation


def test_receipt_projection_apply_kernel_matches_formal_model() -> None:
    """Replays LazilyFormal.Receipt.apply named theorems as concrete cases."""
    base = CausalReceipt(
        receipt_id="r",
        causation_id="c",
        observer="o",
        generation=3,
        outcome=ReceiptOutcome.OBSERVED,
    )

    # duplicate_receipt_noop — same receipt_id is a no-op regardless of body.
    proj = ReceiptProjection("c", 3)
    assert proj.apply(base) is ReceiptApplyResult.RECORDED
    dup = CausalReceipt(
        receipt_id="r",
        causation_id="c",
        observer="o",
        generation=3,
        outcome=ReceiptOutcome.REJECTED,
    )
    assert proj.apply(dup) is ReceiptApplyResult.DUPLICATE
    assert proj.terminal_outcome is None  # duplicate did not flip state

    # stale_generation_discarded — older generation is ignored.
    proj = ReceiptProjection("c", 3)
    stale = CausalReceipt(
        receipt_id="r2",
        causation_id="c",
        observer="o",
        generation=2,
        outcome=ReceiptOutcome.APPLIED,
    )
    assert proj.apply(stale) is ReceiptApplyResult.STALE_GENERATION
    assert proj.terminal_outcome is None
    assert proj.stale_receipt_ids() == ["r2"]

    # nonterminal_records_without_terminal_conflict.
    proj = ReceiptProjection("c", 3)
    nt = CausalReceipt(
        receipt_id="r3",
        causation_id="c",
        observer="o",
        generation=3,
        outcome=ReceiptOutcome.ACCEPTED,
    )
    assert proj.apply(nt) is ReceiptApplyResult.RECORDED
    assert proj.terminal_outcome is None

    # first_terminal_records.
    proj = ReceiptProjection("c", 3)
    term = CausalReceipt(
        receipt_id="r4",
        causation_id="c",
        observer="o",
        generation=3,
        outcome=ReceiptOutcome.APPLIED,
    )
    assert proj.apply(term) is ReceiptApplyResult.RECORDED
    assert proj.terminal_outcome is ReceiptOutcome.APPLIED

    # distinct_terminal_conflicts — second different terminal outcome fails closed.
    other = CausalReceipt(
        receipt_id="r5",
        causation_id="c",
        observer="o",
        generation=3,
        outcome=ReceiptOutcome.REJECTED,
    )
    assert proj.apply(other) is ReceiptApplyResult.TERMINAL_CONFLICT
    assert proj.terminal_outcome is ReceiptOutcome.APPLIED  # unchanged
    assert proj.in_conflict
    assert proj.conflicting_receipt_ids() == ["r5"]


def test_receipt_projection_same_terminal_outcome_is_idempotent() -> None:
    """A second terminal receipt with the SAME outcome re-records without conflict."""
    proj = ReceiptProjection("c", 1)
    first = CausalReceipt("a", "c", "o", 1, ReceiptOutcome.APPLIED)
    second = CausalReceipt("b", "c", "o", 1, ReceiptOutcome.APPLIED)
    assert proj.apply(first) is ReceiptApplyResult.RECORDED
    assert proj.apply(second) is ReceiptApplyResult.RECORDED
    assert proj.terminal_outcome is ReceiptOutcome.APPLIED
    assert not proj.in_conflict


def test_receipt_projection_ignores_other_causation_ids() -> None:
    proj = ReceiptProjection.from_receipts(
        "c1",
        [
            CausalReceipt("r1", "c1", "o", 5, ReceiptOutcome.APPLIED),
            CausalReceipt("r2", "c2", "o", 5, ReceiptOutcome.REJECTED),
        ],
    )
    assert proj.terminal_outcome is ReceiptOutcome.APPLIED
    assert proj.current_generation == 5


def test_causal_receipts_frame_round_trips() -> None:
    fixture = load_fixture("receipts/causal_receipts.json")
    frame = CausalReceipts.from_wire(fixture["wire"])
    assert frame.to_wire() == fixture["wire"]
    assert CausalReceipts.decode_json(frame.encode_json()) == frame
